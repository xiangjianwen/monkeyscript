// ==UserScript==
// @name eruda 手机网页调试
// @namespace Violentmonkey Scripts
// @require https://cdn.jsdelivr.net/npm/eruda
// @match *://*/*
// @grant none
// ==/UserScript==
eruda.init();