// ==UserScript==
// @name 中考分数查询
// @require https://code.jquery.com/jquery-2.1.4.min.js
// @namespace Violentmonkey Scripts
// @match http://www.srjyyun.com/Areas/gradesProject/*
// @grant        GM_setValue
// @grant        GM_getValue
// ==/UserScript==
var my = document.createElement("divCell");
document.body.appendChild(my); 
my.innerHTML='<div  style="position:fixed ; bottom:0px;width:1002" lign="left" id="bg">   <input type="button" name="tijiao" id="tijiao" value="开始爬取分数" /><label id ="l"style="background-color:white;">0</label  ><br/><input type="button" name="zddt" id="bc" value="保存分数到缓存" /><label id ="l2"style="background-color:white;">0</label  ></div>';
var s="";
var k=0;
var  score="";  var cid;
var j=0;
$("#bc").click(function(){//保存变量
     //console.log(score);
     //
     GM_setValue("g", score)
  $("#l2").text("保存长度"+score.length)
   });


function btn_clinck(name, cardid) {
    var name = jsencrypt("e10adc3949ba59abbe56e057f20f883e", name);
    var cardnumber = jsencrypt("e10adc3949ba59abbe56e057f20f883e", cardid);

    if (name != "" && cardnumber != "") {
        $.post("Detils.ashx", {
            "jsonType": "Index",
            "card": name,
            "cardnumber": cardnumber
        }, function(mag) {
            var info = eval("(" + mag + ")");
            if (info.ret == 1) {
              // console.log(mag)
                //$("#uname").val($("#uname").val()+mag);
                score=score+mag
            }
        });
    }
};
$("#tijiao").click(function(){  
var i = "徐汉俊,吴孝俊,聂志峰,汪云杰,裴光旭,陈炯兆,蒋宝亮,王叶林,邱金伟,程甫东,林政岳,童长妙,张雨洁,张星宇,陈志豪,陈雨珊,冯新洋,林佳慧,连忠诚,徐久原,吴世玉,周俊伟,符鸿凯,周敬鑫,陈义,黄卓轩,徐怡欣,郑增超,程禄钧,张静芳,谢兴锦,杨明清,胡一凯,苏瑞文,王冰心,姚权,周永万,张持南,方好,盛纯程,王蓉蓉,郑小平,彭伟越,缪饶,陈羽彤,余厚发,叶佳丽,饶王祥,陈国庆,周小娟,方逸轩,张梦婷,徐诗亮,潘天机,吴永正,张剑云";

var name=i.split(","); 
var card = ["112103229","112102625","112103227","112111402","112102725","112109008","112102523","112102729","112102627","112114310","112102802","112103304","112102702","112102527","112102529","112102804","112105504","112102602","112102904","112102604","112102704","112103004","112102504","112102906","112103106","112102606","112103006","112102806","112102706","112102929","112103202","112102727","112103129","112102825","112132609","112102827","112103302","112102925","112102927","112103029","112133303","112102829","112103027","112102902","112102525","112102129","112103104","112103025","112103204","112103127","112103306","112103125","112102629","112104304","112103002","112103206"];

var s=""
var c=[];
  console.log(name.length)
//for(var j=0;j<name.length;j++)
//{if(name[j]!=","){
  //s=s+name[j]
    //}else
  // {
      // console.log(s);
       //c.push(s)
     //  s="";
      //}
  //}
    
//console.log(name[0])
//console.log(card[0])
var f = function(i) {
    setTimeout(　　function() {

        btn_clinck(name[i], card[i]);
        
console.log(i);
      $("#l").text(i)
        　　　　
    }, 　　50*i)

}
for(var k=0;k<55;k++){
    f(k);
    
    }
  
});   