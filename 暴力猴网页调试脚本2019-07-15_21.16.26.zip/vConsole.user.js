// ==UserScript==
// @name vConsole
// @namespace Violentmonkey Scripts
 // @require https://cdnjs.cloudflare.com/ajax/libs/vConsole/3.2.0/vconsole.min.js
// @match *://*/*
// @grant none
// ==/UserScript==
 var vConsole = new VConsole();  
console.log('Hello world');
